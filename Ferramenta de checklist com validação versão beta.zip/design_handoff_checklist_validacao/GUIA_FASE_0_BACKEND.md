# Guia da Fase 0 — Habilitar uso compartilhado (backend)

> Passo a passo para um desenvolvedor transformar o protótipo (hoje com dados no navegador) em um sistema **multiusuário com base única e login real**. Escopo da **Fase 0** (operação manual, sem agentes). Estimativa: ~2–4 semanas, 1 dev.

---

## O problema a resolver

O protótipo guarda todo o estado em `localStorage` (por navegador/dispositivo). Para uso compartilhado, esse estado precisa migrar para um **banco de dados central** acessado por todos, com **autenticação**. A interface e as regras já estão prontas no protótipo — o trabalho é a camada de dados + auth + deploy.

## Stack recomendada (menor esforço)

- **Frontend:** reconstruir o protótipo no stack do grupo (sugerido **React + Vite**), reaproveitando a UI/regras do `.dc.html` como referência fiel.
- **Backend-as-a-service:** **Supabase** (Postgres + Auth + API REST/Realtime, camada gratuita generosa) — ou **Firebase** (Firestore + Auth) se a equipe já usar Google.
- **Hospedagem do frontend:** **Vercel**, **Netlify** ou **Cloudflare Pages** (deploy a partir do repositório Git).

> Por que BaaS: entrega banco, login e API prontos. Não há servidor a manter nesta fase. Migrar para backend próprio depois é possível sem refazer o frontend.

## Passo a passo (Supabase)

1. **Criar projeto no Supabase** e copiar `Project URL` + `anon key`.
2. **Modelar as tabelas** (ver "Esquema" abaixo) — usar o editor SQL do Supabase.
3. **Ativar Auth** com login por e-mail. Restringir ao domínio `@grupocataratas.com`. Idealmente configurar SSO com Microsoft 365 / Google Workspace (Supabase suporta provedores OAuth).
4. **Definir RLS (Row Level Security):** todos os usuários autenticados leem o estado; ações de configuração (projetos, atividades, empresas, acessos) e a revisão manual só para perfil `admin`. Colaborador só altera o status das próprias entregas (reportar/corrigir).
5. **Trocar o `localStorage` pela API:** onde o protótipo lê/grava o estado (ver `persist()` / `loadPersisted()` e os métodos `report/approveReview/submitReview/correct/revalidate`), chamar o cliente Supabase. Usar **Realtime** para o board atualizar ao vivo entre usuários.
6. **Deploy do frontend** na Vercel/Netlify apontando para o Supabase. Pronto: link único, dados compartilhados, login corporativo.

## Esquema de dados (a partir do protótipo)

```
users        (id, email, name, role)                      role: 'admin' | 'colaborador'
companies    (id, name, active)
projects     (id, name, type, period, pmo, status)        type: mensal|anual|auditoria|pontual
activities   (id, name, section, code, due, resp_user, checks[], enabled_companies[])
deliveries   (project_id, activity_id, company_id,         -- a "matriz"
              status, failed_check, message, corrected)    status: pendente|validando|aprovado|inconsistencia|corrigindo
settings     (validation_mode)                             'manual' | 'agente'
```

> No modo manual (Fase 0), `message` recebe o texto que o revisor digita ao marcar a inconsistência; `failed_check` fica nulo. Quando os agentes entrarem (fases seguintes), eles preenchem `failed_check` e `message` automaticamente.

## Fluxo de validação manual (Fase 0)

1. Colaborador muda a entrega para `validando` (reportar).
2. Admin/revisor: `aprovado` (Validar) **ou** `inconsistencia` + `message` (Marcar inconsistência).
3. Responsável: `corrigindo` (Analisar e corrigir) → `validando` (reenviar).
4. Revisor revalida. Loop até `aprovado`.

A interface inteira já existe no protótipo (seletor Manual/Agente no menu lateral, botões Validar / Marcar inconsistência, campo de devolução).

## Quando ligar os agentes (fases seguintes)

A camada de agentes pluga sem mexer no frontend: um serviço (ex: **Supabase Edge Function** ou job agendado) observa entregas em `validando` no modo `agente`, roda a verificação (lê a pasta de rede / chama a API existente), e grava `aprovado` ou `inconsistencia` + `message`. Ver a especificação completa de cada agente em `Especificação dos Agentes.dc.html`.

## Checklist de deploy

- [ ] Projeto Supabase criado, tabelas e RLS configuradas
- [ ] Login restrito ao domínio corporativo (idealmente SSO)
- [ ] Frontend conectado ao Supabase (leitura/escrita + realtime)
- [ ] Deploy na Vercel/Netlify/Cloudflare
- [ ] Seed inicial: empresas, atividades e usuários reais (ver dados-exemplo no protótipo)
- [ ] Backup do banco e trilha de auditoria habilitados (dados contábeis)
