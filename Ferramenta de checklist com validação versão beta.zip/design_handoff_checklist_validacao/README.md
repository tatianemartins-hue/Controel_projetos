# Handoff: Ferramenta de Checklist com Validação por Agentes

> **Grupo Cataratas — Contabilidade / Fechamento**
> Pacote para a equipe de desenvolvimento (TI ou fornecedor) implementar a ferramenta em ambiente de produção.

---

## Visão geral

Ferramenta que controla o checklist de atividades do fechamento contábil **por empresa** e **por responsável**. Quando um colaborador reporta a conclusão de uma atividade para uma empresa, um **agente de validação** é acionado: roda verificações configuráveis, e ao encontrar uma inconsistência devolve o item ao responsável com a descrição do problema para correção. Corrigido e reenviado, o agente revalida.

Os "agentes" são, na prática, **conjuntos de verificações de erro** aplicados por atividade (hiperpersonalizáveis — cada atividade liga só as que fazem sentido).

Há também um **Agente PMO** para projetos pontuais: não valida números, faz gestão do andamento.

## Sobre os arquivos deste pacote

Os arquivos aqui são **referências de design feitas em HTML** — um protótipo navegável que mostra o visual e o comportamento pretendidos, **não código de produção para copiar diretamente**. A tarefa é **recriar este design no ambiente/stack do Grupo Cataratas** (React, Vue, etc., conforme o padrão existente) — ou, se não houver ambiente, escolher o framework mais adequado — implementando backend, autenticação e os agentes reais por trás da mesma interface.

- `Checklist de Validação.dc.html` — protótipo completo e funcional (frontend + lógica simulada, dados em `localStorage`).
- `Especificação dos Agentes.dc.html` — especificação detalhada dos agentes, arquitetura, modelo de dados e revisão de complexidade. **Leia primeiro.**

> Formato `.dc.html`: abre direto no navegador. É um Design Component — HTML com estilos inline e uma classe de lógica JS embutida. Use como referência visual e de regras, não como base de código.

## Fidelidade

**Alta fidelidade (hi-fi).** Cores, tipografia, espaçamentos e interações são finais. O frontend de produção deve reproduzir a interface fielmente usando as bibliotecas/padrões do codebase do grupo.

---

## Arquitetura-alvo

| Camada | Estado | Descrição |
|---|---|---|
| 1. Interface (frontend) | **Pronta no protótipo** | Reconstruir no stack do grupo usando o protótipo como referência fiel. |
| 2. Backend + banco | A construir | Fonte única: usuários, projetos, empresas, atividades, matriz de entregas, inconsistências. Expõe API ao frontend. |
| 3. Agentes de validação | **Core** | Disparados ao reportar uma entrega. Leem pasta de rede e/ou chamam a API existente, comparam e gravam resultado. |
| 4. Acesso + infra | A construir | Login corporativo (M365/Google), hospedagem em nuvem, backup, credenciais do agente, trilha de auditoria. |

### Revisão de complexidade (importante)

Premissa confirmada pela Contabilidade: os agentes **consultam arquivos em pasta de rede** e **no máximo leem/atualizam dados de uma consulta que já funciona via API**. Portanto **não há integração com ERP a construir do zero** — o agente apenas consome a API existente e compara. Isso reposiciona o trabalho de "projeto grande" para **projeto moderado e bem delimitado** (ordem de grandeza: 1 dev full-stack, ~4–8 semanas do MVP ao primeiro agente real). O protótipo elimina a fase de descoberta de UX e regras.

### Fase 0 — operação sem agentes (modo manual)

Caminho de início recomendado: subir **sem nenhum agente automático**. A validação é **manual** — uma pessoa da Contabilidade revisa cada item reportado (aprova ou marca inconsistência digitando o motivo). Mesmo fluxo, sem balão de agente. Reduz a complexidade para **baixa** (~2–4 semanas, 1 dev, sem dependências externas) e já substitui o Asana. Os agentes entram depois, um a um, sem mexer na interface.

**No protótipo:** o menu lateral tem um seletor **Manual / Agente** (visão de admin) que alterna entre os dois modos. No modo Manual, ao reportar uma entrega o item entra na fila de revisão; o admin vê os botões **Validar** / **Marcar inconsistência** (este abre um campo de texto para a devolução). No modo Agente, a validação é automática (simulada). Ver `Especificação dos Agentes.dc.html`, seção 03.

---

## Telas / Views

### 1. Login
- **Propósito:** autenticar por e-mail corporativo. Perfil (colaborador/admin) vem do cadastro.
- **Layout:** centralizado, card único (max-width 392px) sobre fundo radial escuro. Logo + título + campos e-mail/senha + botão "Entrar" + atalhos de demo.
- **Produção:** trocar senha fixa por SSO corporativo (Microsoft 365 / Google Workspace). Perfil determina permissões.

### 2. Seleção de projeto
- **Propósito:** escolher o fechamento/trabalho antes de entrar no painel.
- **Layout:** header (logo + usuário + Sair) e área rolável com três blocos: **Fechamento mensal** (grid de cards ~210px), **Anual e auditoria** (cards ~280px), **Projetos pontuais · acompanhamento** (cards roxos, badge "Gestão PMO").
- **Card de projeto:** badge de tipo, badge de status (Concluído/Em andamento/Não iniciado), nome, período, barra de progresso, "X/Y validadas", e contagem de inconsistências quando houver. Pontuais mostram selo "Agente PMO" e barra roxa.
- **Cada projeto tem seu próprio estado** (matriz independente).

### 3. Painel (board)
- **Propósito:** acompanhar e operar o checklist do projeto selecionado.
- **Layout:** sidebar fixa (236px) + main. Sidebar: logo, navegação (Fechamento / Inconsistências [badge] / Configurações [só admin]), e card "Biblioteca de verificações".
- **Header:** link "‹ Todos os projetos", título = nome do projeto, badge de status, banner de papel (gestão vs colaborador), usuário + Sair.
- **Banner PMO** (só projetos com PMO ligado): faixa roxa no topo com status (No prazo / Em andamento / Atenção) e leitura automática de pendências/inconsistências.
- **Stats:** 5 cards (Atividades, Validadas, Em validação, Inconsistências, Pendentes).
- **Duas visões** (abas "Por atividade" / "Por empresa"):
  - **Por atividade:** agrupado por seção (Ebitda / Pós Ebitda / Rotina). Cada linha: código do dia, nome, agente + nº de verificações, mini-grid de células coloridas (uma por empresa = status), responsável (avatar), prazo, progresso. Filtros: Todas / Com inconsistência / Pendentes.
  - **Por empresa:** chips de empresa (Todas + cada uma). Mostra **só pendências em aberto** por empresa (itens validados ficam ocultos). "Todas as empresas" prioriza visão consolidada.

### 4. Drawer da atividade (painel lateral direito)
- **Propósito:** ver/operar a entrega de uma atividade por empresa.
- **Conteúdo:** cabeçalho (código, seção, prazo, nome, descrição, responsável, agente). **Admin:** bloco "Configuração do agente" com toggles das 5 verificações (liga/desliga por atividade). **Colaborador:** bloco read-only "Validação automática" listando as verificações ativas. Abaixo: **lista de empresas** com o status de cada uma e a ação contextual:
  - *Pendente* → botão "Reportar conclusão"
  - *Validando* → spinner "Validando…"
  - *Validado* → ✓
  - *Inconsistência* → balão do agente com a verificação que falhou + mensagem + "Analisar e corrigir"
  - *Corrigindo* → "Reenviar p/ validação"

### 5. Inconsistências
- Lista os itens sinalizados no projeto. **Filtros: por empresa e por responsável.** Cada card: código, atividade, empresa, verificação que falhou, mensagem do agente, responsável, botão "Analisar e corrigir".

### 6. Configurações (só admin) — 4 abas
- **Empresas:** cadastrar, **editar** (renomear), ativar/inativar, remover.
- **Atividades:** cadastrar (nome, dia, seção, responsável, prazo, verificações, empresas habilitadas), **editar** os mesmos campos, ligar/desligar verificações e empresas habilitadas por chips, remover.
- **Acessos:** cadastrar usuário (e-mail, nome, perfil), **editar** nome/perfil.
- **Projetos:** cadastrar (nome, tipo mensal/anual/auditoria/pontual, período, toggle Agente PMO), **editar**, remover. Projetos pontuais aparecem em bloco separado na seleção.

---

## Interações & comportamento

- **Reportar → validar:** ao reportar, status → `validando`; após processamento do agente, → `validado` ou `inconsistencia` (com `failedCheck` + mensagem).
- **Corrigir → revalidar:** `inconsistencia` → `corrigindo` (ação do responsável) → `validando` (reenvio) → `validado`.
- **Permissões:** configuração de agente e abas de Configurações só para `admin`. Colaborador vê verificações em read-only.
- **Persistência:** o protótipo persiste por projeto em `localStorage` (chave versionada). Em produção isto vira o **banco compartilhado**.
- **Animações:** spinner de validação (rotação 0.7s), balão de inconsistência (rise 0.3s), drawer (slide-in 0.28s), pulse no indicador "corrigindo".

## Estado / dados

Variáveis de estado centrais (ver classe `Component` no `.dc.html`): `auth`, `currentProject`, `projects`, `matrices` (estado por projeto: `atividade_empresa` → `{status, failedCheck, corrected}`), `companies`, `activities`, `users`, `agentConfig` (verificações ativas por atividade), `selected` (drawer), `view`, `filter`, `company`, `configTab`, filtros de inconsistência (`incCompany`, `incUser`), e estados de edição.

### Modelo de dados (entidades para o backend)
- **Projeto:** id, nome, tipo (mensal/anual/auditoria/pontual), período, pmo (bool), modo/status.
- **Empresa:** id, nome, ativa (bool).
- **Atividade:** id, nome, seção, código/dia, prazo, responsável, verificações ativas, empresas habilitadas.
- **Entrega (matriz):** atividade × empresa × projeto → status, verificação que falhou, mensagem, corrigido.
- **Usuário:** e-mail, nome, perfil (colaborador/admin).
- **Verificação:** código (AR/N°/CC/RB/R$), nome, descrição, parâmetros (tolerância, faixa, fórmula).

### Os 5 agentes (verificações) + PMO
Detalhe completo (gatilho, fonte, lógica, mensagem) em `Especificação dos Agentes.dc.html`. Resumo:
- **AR — Arquivo na rede:** confere existência/local do arquivo na pasta de rede. (sem API)
- **N° — Números registrados:** confronta total reportado × API existente, com tolerância.
- **CC — Centro de custo:** valida CC lançado × cadastro da empresa.
- **RB — Recálculo de base:** recalcula via fórmula × valor no sistema.
- **R$ — Valor imputado:** verifica faixa esperada por conta.
- **◆ PMO:** agrega o estado do projeto e reporta status de gestão (não valida números).

---

## Design tokens

**Cores (tema escuro do app)**
- Fundo app `#080d15`; sidebar `#0b1320`; cards `#0d1622` / `#0e1825`; bordas `#17212f` / `#1a2533`.
- Texto: principal `#dfe6f0` / `#eaf1f8`; secundário `#7c8aa0`; sutil `#566275`.
- Verde primário (marca) `#34c27d`; verde escuro `#1b8a5a`.
- Status: validado `#36c08a`; validando `#56c6f5`; inconsistência `#f2a13d`; pendente `#5a6678` / `#3a4759`; corrigindo `#a78bfa`.
- PMO/pontual roxo `#7a6cf0` / `#a99af5`.

**Tipografia**
- UI: **Manrope** (400–800).
- Números/códigos: **IBM Plex Mono**.
- Documento de especificação usa **Newsreader** (serif) nos títulos.

**Raios:** cards 12–14px; chips/botões 8–10px; avatares 50%.
**Sombras:** drawer e cards usam sombras suaves; ver inline styles.

## Assets

Nenhuma imagem externa. Logo desenhado em CSS (quadrado verde + círculo). Ícones são glifos de texto (◆ ✓ › ✕). Fontes via Google Fonts.

## Arquivos neste pacote

- `Checklist de Validação.dc.html` — protótipo navegável (referência de UI + regras).
- `Especificação dos Agentes.dc.html` — especificação técnica dos agentes (ler primeiro).
- `README.md` — este documento.

> Os `.dc.html` dependem de um runtime (`support.js`) presente no projeto original para rodar; para implementação, eles servem como **referência** — não é necessário portar o runtime. Abra-os no navegador a partir do projeto original se quiser ver funcionando.
